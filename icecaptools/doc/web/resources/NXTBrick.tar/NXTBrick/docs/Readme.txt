HOW-TO NXTBrick
========================================

Project NXTBrick is in C:\hso\Java\OOP_Workspace

Development:

a) Package NXTBrick -> src -> Brick.java -> main
   (husk at "�bne" for Brick.java, s� main kan ses):
     right-click -> Icecap tools -> Convert to Icecap Application

   //The result is in HelloBrick -> src -> main.rfw

b) Cygwin:
     cd  /cygdrive/c/hso/Java/OOP_Workspace/HelloBrick/src

     $ ./compile.sh
     
c) LEGO MINDSTORMS NXT tool:
     Tools -> Update NXT Firmware... 
     -> Browse: C:\hso\Java\OOP_Workspace\HelloBrick\src
     
     Download.
     Before Download: reset the Brick by pressing buttom (upper left corner)
     about 3 sec.