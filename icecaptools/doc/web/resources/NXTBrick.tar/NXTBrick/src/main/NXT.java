package main;

public class NXT {
	public static Display display;

	static {
		display = new Display();
	}
}
