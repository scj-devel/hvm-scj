package main;

public class Brick {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = NXT.display;
		
		String s1 = "ABCDE FGHIJ ";
		String s2 = "KLMNO PQRST ";
		String s3 = "UVWXYZ";
		String s4 = "01234 56789 ";
		String s5 = "+ , - . / ";
		String s6 = ": ; < = > ? ";
		
		String s7 = "(";  // not included in C64Font.fonts table; default prints a square
		
		display.gotoLine((byte)0);
		display.print(s1);
		display.gotoLine((byte)1);
		display.print(s2);
		display.gotoLine((byte)2);
    display.print(s3);
    display.gotoLine((byte)3);
    display.print(s4);
    display.gotoLine((byte)4);
    display.print(s5);
    display.gotoLine((byte)5);
    display.print(s6);
    display.gotoLine((byte)6);
    display.print(s7);
		
//		display.printAt((byte)3, s1);
		
//		 for (byte i = 0; i < 8; i++)
//		   display.printAt(i, s1);
		
//		byte b0 = (byte)0x00;
//		byte b1 = (byte)0xff;
//		for (byte j = 0; j < 10; j++)
//    {
//		  display.print(b0);
//		  display.print(b1);
//    }
//		args = null;
	}
}
