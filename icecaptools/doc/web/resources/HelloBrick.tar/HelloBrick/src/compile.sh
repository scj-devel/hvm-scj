#!/bin/sh

rm -f *.o
rm -f main.rfw

# HVM specific files
../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c icecapvm.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c natives_allOS.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c methodinterpreter.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c allocation_point.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c methods.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c classes.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c gc.c

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DJAVA_HEAP_SIZE=8192 -DJAVA_STACK_SIZE=1024 -DEXCLUDEMAIN -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 -c print.c
# Native layer required to get int main

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 sam7s256.c -o sam7s256.o

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mcpu=arm7tdmi -mthumb-interwork -I. -x assembler-with-cpp -DROM_RUN -DVECTORS_IN_RAM -Wa,-adhlns=Cstartup.lst,--gdwarf-2 Cstartup.S -o Cstartup.o

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 Cstartup_SAM7.c -o Cstartup_SAM7.o

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -c -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w -ffunction-sections -fdata-sections -ffreestanding -Wnested-externs  -std=gnu99 d_display.c -o d_display.o

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-gcc -mthumb -mcpu=arm7tdmi -mthumb-interwork -I.  -DROM_RUN -DSAM7S256 -DPROTOTYPE_PCB_4 -D__ICCARM__ -DNEW_MENU -DSTARTOFUSERFLASH=0x136C00L   -DVECTORS_IN_RAM  -Os -w *.o --output main.elf -nostartfiles -Wl,-Map=main.map,--cref,--gc-sections -lc  -lm -lc -lgcc     -TAT91SAM7S256-ROM.ld 

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-objcopy --pad-to=0x140000 --gap-fill 0x00 -O binary main.elf main.bin

../../../nxtgcc/NXTGCCECLIPSE/workspace/NXTGCC/LEGO-MINDSTORMS-NXT-Firmware-Open-Source/AT91SAM7S256/nxtgcc/utils/binsert.exe ../../../nxtgcc/NXTGCCECLIPSE/workspace/NXTGCC/LEGO-MINDSTORMS-NXT-Firmware-Open-Source/AT91SAM7S256/nxtgcc/utils/LEGO-MINDSTORMS-NXT-Firmware-v1.05.rfw 0x3FFFC 4 main.bin 0x3FFFC

cp main.bin main.rfw

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-objdump -h -S -C main.elf > main.lss

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-nm -n main.elf > main.sym

../../../nxtgcc/NXTGCCECLIPSE/eclipse/armelfgcc/bin/arm-elf-size -A main.elf





