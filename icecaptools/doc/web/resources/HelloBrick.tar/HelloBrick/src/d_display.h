//
// Programmer      
//
// Date init       14.12.2004
//
// Reviser         $Author: skr $
//
// Revision date   $Date: 2013/08/07 14:30:06 $
//
// Filename        $Workfile:: d_display.h                                   $
//
// Version         $Revision: 1.1 $
//
// Archive         $Archive:: /LMS2006/Sys01/Main/Firmware/Source/d_display. $
//
// Platform        C
//

#ifndef   D_DISPLAY
#define   D_DISPLAY

void      dDisplayInit(void);
void      dDisplayOn(UBYTE On);
UBYTE     dDisplayUpdate(UWORD Height,UWORD Width,UBYTE *pImage);
void      dDisplayExit(void);



typedef   struct    
{
  UBYTE   StartX;
  UBYTE   StartY;
  UBYTE   PixelsX;
  UBYTE   PixelsY;
}
SCREEN_CORDINATE;


#endif
