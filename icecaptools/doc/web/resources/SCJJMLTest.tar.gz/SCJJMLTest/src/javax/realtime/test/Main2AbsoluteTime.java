package javax.realtime.test;

import javax.realtime.AbsoluteTime;

public class Main2AbsoluteTime
{

  public static void main (String[] args)
  {
    AbsoluteTime abs = new AbsoluteTime(1,-1); 
    
    devices.Console.println("abs: " + abs);
    
//    int this_nanos = abs.getNanoseconds();
//    int param_nanos = 1000001;
       
    //AbsoluteTime result = abs.add(0,1000001,abs);
    abs = abs.add(0,1000001,abs);
    
    devices.Console.println("abs: " + abs);
    //devices.Console.println("result: " + abs);
    
    //ensures  (\result.getNanoseconds() - this.getNanoseconds() - nanos) % 1000000  == 0;
    
//    int r = (result.getNanoseconds() - this_nanos - param_nanos) % 1000000;
//    
//    devices.Console.println("r: " + r);

  }

}
