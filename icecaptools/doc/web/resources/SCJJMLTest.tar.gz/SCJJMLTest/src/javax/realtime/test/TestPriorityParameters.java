package javax.realtime.test;

import javax.realtime.PriorityParameters;
import javax.safetycritical.PriorityScheduler;
import org.jmlspecs.jml4.rac.runtime.JMLPreconditionError;
import unitTest.TestCase;

public class TestPriorityParameters extends TestCase
{
  public TestPriorityParameters(String name)
  {
    super(name);
  }
  
  public void test (int i) 
  {
    int min = PriorityScheduler.instance().getMinPriority();
    int max = PriorityScheduler.instance().getMaxPriority();
    switch (i) {
               // public PriorityParameters(int priority)
      case  1: try{new PriorityParameters(min-1); }
               catch (JMLPreconditionError e){}; break;
      case  2: new PriorityParameters(min); break;
      case  3: new PriorityParameters((min+max)/2); break;
      case  4: new PriorityParameters(max); break;      
      case  5: try{new PriorityParameters(max+1); }
               catch (JMLPreconditionError e){}; break;
               
               // public int getPriority()
      case  6: new PriorityParameters((min+max)/2).getPriority(); break;
      
               // public void setPriority (int value)
      case  7: try {new PriorityParameters(min).setPriority(min-1);}
               catch (JMLPreconditionError e){}; break;               
      case  8: new PriorityParameters(min+1).setPriority(min); break;
      case  9: new PriorityParameters(min).setPriority((min+max)/2); break;
      case 10: new PriorityParameters(min).setPriority(max); break;      
      case 11: try {new PriorityParameters(min).setPriority(max+1);}
               catch (JMLPreconditionError e){} break;
      default: break;
    }
  }
  
  public static final int testCount = 11;  
}
