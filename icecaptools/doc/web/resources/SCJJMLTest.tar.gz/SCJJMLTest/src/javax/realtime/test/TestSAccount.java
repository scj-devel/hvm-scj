package javax.realtime.test;

import jml.test.apr.SAccount;

import unitTest.TestCase;

public class TestSAccount extends TestCase
{
  public void test(int i) { 
    switch (i) {      
      case  1: SAccount._instance_(); break;
      
      default: break;
    }
  }
  
  public static final int testCount = 1;  
}
